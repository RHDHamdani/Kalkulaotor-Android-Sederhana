package ac.id.poltekkampar.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button Angka1, Angka2, Angka3, Angka4, Angka5, Angka6, Angka7, Angka8, Angka9, Angka0;
    TextView textView;
    Button clear, koma, kali, bagi, tambah, kurang, samaDG, backspace;

    String angka;
    double N1, N2, jumlah;
    int pilih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        angka = "";

        textView = findViewById(R.id.textView);
        Angka1 = findViewById(R.id.angka1);
        Angka2 = findViewById(R.id.angka2);
        Angka3 = findViewById(R.id.angka3);
        Angka4 = findViewById(R.id.angka4);
        Angka5 = findViewById(R.id.angka5);
        Angka6 = findViewById(R.id.angka6);
        Angka7 = findViewById(R.id.angka7);
        Angka8 = findViewById(R.id.angka8);
        Angka9 = findViewById(R.id.angka9);
        Angka0 = findViewById(R.id.angka0);
        koma = findViewById(R.id.koma);
        kali = findViewById(R.id.kali);
        bagi = findViewById(R.id.bagi);
        tambah = findViewById(R.id.tambah);
        kurang = findViewById(R.id.kurang);
        samaDG = findViewById(R.id.samaDG);
        backspace = findViewById(R.id.backspace);
        clear = findViewById(R.id.clear);
        onClick();

    }

    public void onClick() {
        Angka1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "1";
                textView.setText(angka);
            }
        });

        Angka2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "2";
                textView.setText(angka);
            }
        });

        Angka3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "3";
                textView.setText(angka);
            }
        });

        Angka4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "4";
                textView.setText(angka);
            }
        });

        Angka5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "5";
                textView.setText(angka);
            }
        });

        Angka6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "6";
                textView.setText(angka);
            }
        });

        Angka7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "7";
                textView.setText(angka);
            }
        });

        Angka8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "8";
                textView.setText(angka);
            }
        });

        Angka9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "9";
                textView.setText(angka);
            }
        });

        Angka0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += "0";
                textView.setText(angka);
            }
        });
        koma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angka += ".";
                textView.setText(angka);
            }
        });

        kali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                N1 = Double.parseDouble(angka);
                textView.setText("*");
                angka = "";
                pilih = 1;

            }
        });

        bagi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                N1 = Double.parseDouble(angka);
                textView.setText("/");
                angka = "";
                pilih = 2;
            }
        });

        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                N1 = Double.parseDouble(angka);
                textView.setText("+");
                angka = "";
                pilih = 3;
            }
        });

        kurang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                N1 = Double.parseDouble(angka);
                textView.setText("-");
                angka = "";
                pilih = 4;

            }
        });

        samaDG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (pilih) {
                    case 1:
                        N2 = Double.parseDouble(angka);
                        jumlah = N1 + N2;
                        angka = Double.toString(jumlah);
                        textView.setText(angka);
                        break;

                    case 2:
                        N2 = Double.parseDouble(angka);
                        jumlah = N1 / N2;
                        angka = Double.toString(jumlah);
                        textView.setText(angka);
                        break;

                    case 3:
                        N2 = Double.parseDouble(angka);
                        jumlah = N1 + N2;
                        angka = Double.toString(jumlah);
                        textView.setText(angka);
                        break;

                    case 4:
                        N2 = Double.parseDouble(angka);
                        jumlah = N1 - N2;
                        angka = Double.toString(jumlah);
                        textView.setText(angka);
                        break;
                }
            }
        });

        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int panjang = textView.getText().length();
                int nomor = textView.getText().length() - 1;
                String kurang;

                if (panjang > 0) {
                    StringBuilder back = new StringBuilder(textView.getText());
                    back.deleteCharAt(nomor);
                    kurang = back.toString();
                    textView.setText(kurang);
                    angka = (kurang);
                }
                if (angka == ""){
                    textView.setText("0");
                }
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textView.setText("0");
                angka = "";
                N1 = (int) 0.0;
                N2 = (int) 0.0;
                jumlah = (int) 0.0;
            }
        });
    }
}
